<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Supreme Shippers/Your Trusted Delivery Company</title><link rel="shortcut icon" href="img/favicon.ico">

		<link href="css/master.css" rel="stylesheet">

		<!-- SWITCHER -->
		<link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color1.css" title="color1" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color2.css" title="color2" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color3.css" title="color3" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color4.css" title="color4" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color5.css" title="color5" media="all" />
		<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/color6.css" title="color6" media="all" />

		<!--[if lt IE 9]>
		<script src="//oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="//oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
		    <style type="text/css">
    .logintb2 {border: 3px double #009;
	width: 150px;
	padding-left:5px;
	color:#000;
	background-color:#fff;
	font-size:18px;
	font-family:Georgia, "Times New Roman", Times, serif;
}
.style2 {font-size: 18px;
	color: #000099;
}
    </style>
	</head>
	<body data-scrolling-animations="true">
		<div class="sp-body">
			<!-- Start Switcher -->
			
			<!-- End Switcher -->
			<header id="this-is-top">
				<div class="container-fluid">
					<div class="topmenu row">
						<nav class="col-sm-offset-3 col-md-offset-4 col-lg-offset-4 col-sm-6 col-md-5 col-lg-5">
							<a href="privacy.html">PRIVACY</a>
							<a href="terms.html">TERMS &  CONDITIONS</a>
							<a href="about.html">WHY US</a>
						</nav>
						<nav class="text-right col-sm-3 col-md-3 col-lg-3">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-pinterest"></i></a>
							<a href="#"><i class="fa fa-youtube"></i></a>
						</nav>
					</div>
					<div class="row header">
						<div class="col-sm-3 col-md-3 col-lg-3">
							<a href="index.html" id="logo"></a>
						</div>
						<div class="col-sm-offset-1 col-md-offset-1 col-lg-offset-1 col-sm-8 col-md-8 col-lg-8">
							<div class="text-right header-padding">
								<div class="h-block"><span>CALL US</span>(410) 417 8620</div>
								<div class="h-block"><span>EMAIL US</span><a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="f29b9c949db281878280979f97819a9b828297808181dc919d9f">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></div>
								<div class="h-block"><span>WORKING HOURS</span>24/7</div>
								<a class="btn btn-success" href="quote.html">REQUEST A QUOTE</a>
							</div>
						</div>
					</div>
					<div id="main-menu-bg"></div>  
					<a id="menu-open" href="#"><i class="fa fa-bars"></i></a> 
					<nav class="main-menu navbar-main-slide">
						<ul class="nav navbar-nav navbar-main">
							
							<li><a href="index.html">HOME</a></li>
							
							<li><a href="services.html">OUR SERVICES</a></li>

							<li><a href="about.html">ABOUT US</a></li>
							
							<li><a href="tracking.php">TRACK YOUR SHIPMENT</a></li><li><a href="animal.html">ANIMAL SHIPPING</a></li>
							
							<li><a href="contact.html">CONTACT</a></li>
							
							<li><a class="btn_header_search" href="#"><i class="fa fa-search"></i></a></li>
						</ul>
						<div class="search-form-modal transition">
							<form class="navbar-form header_search_form">
								<i class="fa fa-times search-form_close"></i>
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Search">
								</div>
								<button type="submit" class="btn btn_search customBgColor">Search</button>
							</form>
						</div>
	                </nav>
					<a id="menu-close" href="#"><i class="fa fa-times"></i></a> 
				</div>
			</header>

			<div class="bg-image page-title">
				<div class="container-fluid">
					<a href="tracking.php"><h1>TRACK YOUR SHIPMENT</h1></a>
					<div class="pull-right">
						<a href="index.html"><i class="fa fa-home fa-lg"></i></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="tracking.php">TRACK YOUR SHIPMENT</a>
					</div>
				</div>
			</div>

			<div class="container-fluid block-content">
				<div class="row main-grid">
					<div class="col-sm-3 wow slideInUp" data-wow-delay="0.3s">
						<div class="sidebar-container">
							<div>
								<ul class="styled">
									<li class="active"><a href="services.html">VITEX SERVICES</a></li>
									<li><a href="sea.html">SEA FREIGHT</a></li>
									<li><a href="road.html">ROAD TRANSPORTATION</a></li>
									
									<li><a href="air.html">AIR FREIGHT</a></li>
									<li><a href="courier.html">COURIER FREIGHT</a></li>
									<li><a href="animal.html">ANIMAL SHIPPING</a></li>
									<li><a href="railway.html">RAILWAY LOGISTICS</a></li>
									<li><a href="warehousing.html">WAREHOUSING</a></li>
									<li><a href="packaging.html">PACKAGING & STORAGE</a></li>																		
										
									<li><a href="express.html">EXPRESS/GCI</a></li>
									<li><a href="small.html">SMALL PACKAGE</a></li>
									<li><a href="door.html">DOOR TO DOOR</a></li>
									<li><a href="odc.html">ODC CONSIGNMENT</a></li>
									<li><a href="custom.html">CUSTOM CLEARANCE</a></li>
									<li><a href="rental.html">RENTAL OF EQUIPEMENT</a></li>
									<li><a href="shipment.html">SHIPMENT CONSOLIDATION</a></li>
									<li><a href="container.html">CONTAINER LEASING</a></li>
									
										
									
								</ul>
							</div>
						</div>
					</div>
					
					
            <div id="content">
					<br />
					<br />
					<br />
					<br />
					<br />
					<br />
					<br />
					  <div style="width:420px; float:left; padding-top:20px; margin-top:50px; background-color:#A91605; border-radius:5px; margin-left:100px; margin-top:10px; padding:10px; clear:right; color: #ffffff;">
					    <p>For up-to-date shipment tracking information, enter the Supreme Shippers</p>
					    <p>Tracking Code without spaces or dashes</p>                         
					    <p>(example: 40511122121).<br/>
				        <hr style="color:#FFFF00;"/>
					    </p>
					    <form action="cepsonlinetrack.php" method="post" target="_self">
					      <span class="style2"><strong>Tracking Code</strong></span>
					      <input name="txttrackingcode" type="text" class="logintb2" style="border:#00C thin solid; size:14pt; id="" value="" size="25"txttrackingcode="txttrackingcode" />
					      <input name="track" type="submit" class="accordionHeaderSelected" value="Track now" />
					      <span style=" width:180px; float:right; margin-top:5px; margin-right:100px; color:red; border-radius:5px; padding-left:20px; clear:right;"> &nbsp;
					        				          </span><br/>
				        </form>
				      </div>

												

					</div>


					
					
					
				</div>            
			</div>

			<footer>
				<div class="color-part2"></div>
				<div class="color-part"></div>
				<div class="container-fluid">
					<div class="row block-content">
						<div class="col-xs-8 col-sm-4 wow zoomIn" data-wow-delay="0.3s">
							<a href="#" class="logo-footer"></a>
							<p>Experience You Can Count On, Customized Solutions For All Your Shipping Needs.</p>
							<div class="footer-icons">
								<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-pinterest-square fa-2x"></i></a>
								<a href="#"><i class="fa fa-vimeo-square fa-2x"></i></a>
							</div>
							<a href="quote.html" class="btn btn-lg btn-danger">REQUEST A QUOTE</a>
						</div>
						<div class="col-xs-4 col-sm-2 wow zoomIn" data-wow-delay="0.3s">
							<h4>WE OFFERS</h4>
							<nav>
								<a href="sea.html">Sea Freight</a>
								<a href="road.html">Road Transportation</a>
								<a href="air.html">Air Freight</a>
								<a href="railway.html">Railway Logistics</a>
								<a href="packaging.html">Packaging & Storage</a>
								<a href="warehousing.html">Warehousing</a>
							</nav>
						</div>
						<div class="col-xs-6 col-sm-2 wow zoomIn" data-wow-delay="0.3s">
							<h4>MAIN LINKS</h4>
							<nav>
								<a href="index.html">Home</a>
								<a href="services.html">Our Services</a>
								<a href="about.html">About Us</a>
								<a href="privacy.html">Privacy</a>
								<a href="terms.html">Terms & Condition</a>
								<a href="contact.html">Contact</a>
							</nav>
						</div>
						<div class="col-xs-6 col-sm-4 wow zoomIn" data-wow-delay="0.3s">
							<h4>CONTACT INFO</h4>
							Everyday is a new day for us and we work really hard to satisfy our customers everywhere.
							<div class="contact-info">
								<span><i class="fa fa-location-arrow"></i><strong>Supreme Shippers</strong><br>530 Brock Bridge Rd,
Laurel, MD 20724 </span>
								<span><i class="fa fa-phone"></i>(410) 417 8620</span>
								<span><i class="fa fa-envelope"></i><a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="640d0a020b2417111416010901170c0d1414011617174a070b09">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></span>
								<span><i class="fa fa-clock-o"></i>24/7</span>
							</div>
						</div>
					</div>
					<div class="copy text-right"><a id="to-top" href="#this-is-top"><i class="fa fa-chevron-up"></i></a> &copy; 2016 Supreme Shippers All rights reserved.</div>
				</div>
			</footer>
		</div>

		<!--Main-->   
		<script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/modernizr.custom.js"></script>
		<!--Switcher-->
		<script src="assets/switcher/js/switcher.js"></script>
		<!--Owl Carousel-->
		<script src="assets/owl-carousel/owl.carousel.min.js"></script>
		<!-- SCRIPTS -->
	    <script type="text/javascript" src="assets/isotope/jquery.isotope.min.js"></script>
		<!--Theme-->
		<script src="js/jquery.smooth-scroll.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/jquery.placeholder.min.js"></script>
		<script src="js/smoothscroll.min.js"></script>
		<script src="js/theme.js"></script>      
	</body>
</html>